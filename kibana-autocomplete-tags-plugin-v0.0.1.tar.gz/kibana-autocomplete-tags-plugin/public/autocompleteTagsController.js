define(function (require) {
  var module = require('ui/modules').get('kibana/kibana-autocomplete-tags-plugin', ['kibana']);
  module.controller('KbnAutocompleteTagsVisController', function ($scope, $rootScope, $filter, $http, Private) {
    var angular = require('angular');
    var filterManager = Private(require('ui/filter_manager'));
    var self = this
    $rootScope.plugin = {
      autocompleteTagsPlugin: {}
    };
    $scope.founded_tags = []
    $scope.founded_maincategoriestag = []
    $scope.founded_categoriestag = []
    $scope.founded_subcategoriestag = []

    $scope.selected_tags = []
    $scope.selected_maincategoriestag = []
    $scope.selected_categoriestag = []
    $scope.selected_subcategoriestag = []

    $scope.selected_tags_and = []
    $scope.selected_tags_or = []
    $scope.selected_tags_nor = []


    window.drop = function(e){
      e.preventDefault();
      var data = e.dataTransfer.getData("text");
      var key = parseInt(data.split("-")[1])
      var type = data.split("-")[0]

      var item = self.getItemByTypeByKey(type, key)

      if ( $(e.target).hasClass("and") ){
        if ( self.itemExist($scope.selected_tags_and, item) == false ){
          $scope.selected_tags_and.push(item)
        }
      }else if ( $(e.target).hasClass("or") ){
        if ( self.itemExist($scope.selected_tags_or, item) == false ){
          $scope.selected_tags_or.push(item)
        }
      }else if ( $(e.target).hasClass("nor") ){
        if ( self.itemExist($scope.selected_tags_nor, item) == false ){
          $scope.selected_tags_nor.push(item)
        }
      }else{
        if ( self.itemExist($scope.selected_tags, item) == false ){
          $scope.selected_tags.push(item)
        }
      }
    }
    window.allowDrop = function(e){
      e.preventDefault();
    }
    window.drag = function(e){
      e.dataTransfer.setData("text", e.target.id);
    }

    $scope.searchMainCategoriesTag = function(){
      if ( $("#autocomplete-maincategoriestag").val().length >= 3 ){
        $.ajax({
          url: "http://www.jerevedunemaison.com/tag_maincategories/autocompletion.json?term="+$("#autocomplete-maincategoriestag").val(),
          success: function (response) {
            $scope.founded_maincategoriestag = []
            for (item in response){
              $scope.founded_maincategoriestag.push(response[item])
            }
          }
        });
      }
    }
    $('*[data-drag="true"]')
    $scope.searchCategoriesTagByMainCategory = function(){
      if ( $("#autocomplete-categoriestag").val().length >= 3 ){
        maincategory_ids = []
        for ( var i = 0; i < $scope.selected_maincategoriestag.length; i++ ){
          console.log(i)
          maincategory_ids.push($scope.selected_maincategoriestag[i].id)
        }
        $.ajax({
          url: "http://www.jerevedunemaison.com/tag_categories/autocompletion_by_maincategory.json?main_category_id="+maincategory_ids.join(",")+"&term="+$("#autocomplete-categoriestag").val(),
          success: function (response) {
            $scope.founded_categoriestag = []
            for (item in response){
              $scope.founded_categoriestag.push(response[item])
            }
          }
        });
      }
    }

    $scope.searchSubCategoriesTagByCategories = function(){
      if ( $("#autocomplete-categoriestag").val().length >= 3 ){
        category_ids = []
        for ( var i = 0; i < $scope.selected_categoriestag.length; i++ ){
          category_ids.push($scope.selected_categoriestag[i].id)
        }
        $.ajax({
          url: "http://www.jerevedunemaison.com/tag_subcategories/autocompletion_by_category.json?category_id="+category_ids.join(",")+"&term="+$("#autocomplete-subcategoriestag").val(),
          success: function (response) {
            $scope.founded_subcategoriestag = []
            for (item in response){
              $scope.founded_subcategoriestag.push(response[item])
            }
          }
        });
      }
    }

    $scope.searchTagsBySubCategories = function(){
      if ( $("#autocomplete-tags").val().length >= 3 ){
        subcategory_ids = []
        for ( var i = 0; i < $scope.selected_subcategoriestag.length; i++ ){
          subcategory_ids.push($scope.selected_subcategoriestag[i].id)
        }
        $.ajax({
          url: "http://www.jerevedunemaison.com/tags/autocomplete_by_subcategory.json?sub_category_id="+subcategory_ids.join(",")+"&term="+$("#autocomplete-tags").val(),
          success: function (response) {
            $scope.founded_tags = []
            for (item in response){
              $scope.founded_tags.push(response[item])
            }
          }
        });
      }
    }

    $scope.searchTags = function(){
      if ( $("#autocomplete-tags-all").val().length >= 3 ){
        $.ajax({
          url: "http://www.jerevedunemaison.com/tags/autocompletion_all.json?term="+$("#autocomplete-tags-all").val(),
          success: function (response) {
            $scope.founded_tags = []
            for (item in response){
              $scope.founded_tags.push(response[item])
            }
          }
        });
      }
    }

    self.itemExist = function(itemList, item){
      exist = false
      for (j = 0; j < itemList.length; j++){
        if ( itemList[j].name == item.name ){
          return true
        }
      }
      return false
    }

    $scope.selectMainCategorytag = function(maincategory){
      if ( self.itemExist($scope.selected_maincategoriestag, maincategory) == false ){
        $scope.selected_maincategoriestag.push(maincategory)
      }
      $scope.founded_maincategoriestag = []
    }

    $scope.selectCategorytag = function(category){
      if ( self.itemExist($scope.selected_categoriestag, category) == false ){
        $scope.selected_categoriestag.push(category)
      }
      $scope.founded_categoriestag = []
    }

    $scope.selectSubCategorytag = function(subcategory){
      if ( self.itemExist($scope.selected_subcategoriestag, subcategory) == false ){
        $scope.selected_subcategoriestag.push(subcategory)
      }
      $scope.founded_subcategoriestag = []
    }

    $scope.selectTag = function(tag){
      if ( self.itemExist($scope.selected_tags, tag) == false && self.itemExist($scope.selected_tags_or, tag) == false && self.itemExist($scope.selected_tags_and, tag) == false && self.itemExist($scope.selected_tags_nor, tag) == false ){
        $scope.selected_tags.push(tag)
      }
      $scope.founded_tags = []
    }

    $scope.unselectMainCategorytag = function(index){
      $scope.selected_maincategoriestag.splice(index, 1);
    }
    $scope.unselectCategorytag = function(index){
      $scope.selected_categoriestag.splice(index, 1);
    }
    $scope.unselectSubCategorytag = function(index){
      $scope.selected_subcategoriestag.splice(index, 1);
    }
    $scope.unselectTag = function(index){
      $scope.selected_tags.splice(index, 1);
    }
    $scope.unselectTagOr = function(index){
      $scope.selected_tags_or.splice(index, 1);
    }
    $scope.unselectTagAnd = function(index){
      $scope.selected_tags_and.splice(index, 1);
    }
    $scope.unselectTagNor = function(index){
      $scope.selected_tags_nor.splice(index, 1);
    }

    $scope.addTagsToFilter = function(){
      if ( tags_filter = filterManager.filterAlreadyExist("tags") ){
        if (confirm("Vous allez supprimer le filtre tags courant")){
          filterManager.removeOperatorFilter(tags_filter)
        }
      }
      filterManager.add("tags", $scope.selected_tags[0].name, null, "houses").then(function(){
        for (var i = 1; i < $scope.selected_tags.length; i++ ){
          name = $scope.selected_tags[i].name
          filterManager.addOrFilter("tags", name)
        }
      })
    }

    $scope.addFormulaTagsToFilter = function(){
      if ( tags_filter = filterManager.filterAlreadyExist("tags") ){
        if (confirm("Vous allez supprimer le filtre tags courant") == true){
          filterManager.removeOperatorFilter(tags_filter)
        }
      }
      var i_and_start = 0
      var i_or_start = 0
      var i_nor_start = 0
      var operator_first_tag_filter = ""

      if ( $scope.selected_tags_and.length > 0){
        var first_filter = filterManager.add("tags", $scope.selected_tags_and[0].name, null, "houses")
        i_and_start = 1
        operator_first_tag_filter = "must"
      }else if ( $scope.selected_tags_or.length > 0){
        var first_filter = filterManager.add("tags", $scope.selected_tags_or[0].name, null, "houses")
        i_or_start = 1
        operator_first_tag_filter = "should"
      }else if ( $scope.selected_tags_nor.length > 0){
        var first_filter = filterManager.add("tags", $scope.selected_tags_nor[0].name, null, "houses")
        i_nor_start = 1
        operator_first_tag_filter = "must_not"
      }

      first_filter.then(function(){
        for (var i = i_and_start; i < $scope.selected_tags_and.length; i++ ){
          name = $scope.selected_tags_and[i].name
          filterManager.addOperatorFilter("tags", name, "must", operator_first_tag_filter)
        }
        for (var i = i_or_start; i < $scope.selected_tags_or.length; i++ ){
          name = $scope.selected_tags_or[i].name
          filterManager.addOperatorFilter("tags", name, "should", operator_first_tag_filter)
        }
        for (var i = i_nor_start; i < $scope.selected_tags_nor.length; i++ ){
          name = $scope.selected_tags_nor[i].name
          filterManager.addOperatorFilter("tags", name, "must_not", operator_first_tag_filter)
        }
      })
    }

    self.getItemByTypeByKey = function(type, key){
      if ( type == "tag" ){
        item = $scope.selected_tags[key]
        $scope.selected_tags.splice(key, 1)
      }else if (type == "tagand"){
        item = $scope.selected_tags_and[key]
        $scope.selected_tags_and.splice(key, 1)
      }else if (type == "tagor"){
        item = $scope.selected_tags_or[key]
        $scope.selected_tags_or.splice(key, 1)
      }else if (type == "tagnor"){
        item = $scope.selected_tags_nor[key]
        $scope.selected_tags_nor.splice(key, 1)
      }
      return item
    }

    self.initTagsList = function(){
      if ( tags_filter = filterManager.filterAlreadyExist("tags") ){
        if ( tags_filter.bool ){
          if ( tags_filter.bool.should ){
            for (var i=0; i< tags_filter.bool.should.length; i++){
              $scope.selected_tags_or.push({name: tags_filter.bool.should[i].query.match.tags.query})
            }
          }
          if ( tags_filter.bool.must ){
            for (var i=0; i< tags_filter.bool.must.length; i++){
              $scope.selected_tags_and.push({name: tags_filter.bool.must[i].query.match.tags.query})
            }
          }
          if ( tags_filter.bool.must_not ){
            for (var i=0; i< tags_filter.bool.must_not.length; i++){
              $scope.selected_tags_nor.push({name: tags_filter.bool.must_not[i].query.match.tags.query})
            }
          }
        }else{
          $scope.selected_tags.push({name: tags_filter.query.match.tags.query})
        }
      }
    }
    self.initTagsList();
    $scope.config = {};

    $scope.oldValue = null;
  });
});
