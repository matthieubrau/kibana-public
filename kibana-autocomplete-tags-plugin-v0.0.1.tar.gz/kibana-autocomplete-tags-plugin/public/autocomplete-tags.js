define(function (require) {
  require('plugins/kibana-autocomplete-tags-plugin/autocomplete-tags.less');
  require('plugins/kibana-autocomplete-tags-plugin/autocompleteTagsController');
  require('ui/registry/vis_types').register(AutocompleteTagsVisProvider);

  function AutocompleteTagsVisProvider(Private) {
    var TemplateVisType = Private(require('ui/template_vis_type/TemplateVisType'));

    return new TemplateVisType({
      name: 'autocomplete-tags',
      title: 'Tags Filter',
      icon: 'fa-tags',
      description: 'Useful for filtering with dropdown in dashboards.',
      template: require('plugins/kibana-autocomplete-tags-plugin/autocomplete-tags.html'),
      params: {
        editor: require('plugins/kibana-autocomplete-tags-plugin/autocompleteTagsOptions.html')
      },
      requiresSearch: false
    });
  }

  return AutocompleteTagsVisProvider;
});
