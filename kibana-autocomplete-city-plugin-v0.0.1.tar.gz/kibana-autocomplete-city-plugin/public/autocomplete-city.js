define(function (require) {
  require('plugins/kibana-autocomplete-city-plugin/autocomplete-city.less');
  require('plugins/kibana-autocomplete-city-plugin/autocompleteCityController');
  require('ui/registry/vis_types').register(AutocompleteCityVisProvider);

  function AutocompleteCityVisProvider(Private) {
    var TemplateVisType = Private(require('ui/template_vis_type/TemplateVisType'));

    return new TemplateVisType({
      name: 'autocomplete-city',
      title: 'City Filter',
      icon: 'fa-map',
      description: 'Allow to filter on city with OR filter',
      template: require('plugins/kibana-autocomplete-city-plugin/autocomplete-city.html'),
      params: {
        editor: require('plugins/kibana-autocomplete-city-plugin/autocompleteCityOptions.html')
      },
      requiresSearch: false
    });
  }

  return AutocompleteCityVisProvider;
});
