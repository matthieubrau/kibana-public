define(function (require) {
  var module = require('ui/modules').get('kibana/kibana-autocomplete-city-plugin', ['kibana']);
  module.controller('KbnAutocompleteCityVisController', function ($scope, $rootScope, $filter, $http, Private) {
    var angular = require('angular');
    var filterManager = Private(require('ui/filter_manager'));
    $rootScope.plugin = {
      autocompleteCityPlugin: {}
    };
    $scope.founded_cities = []
    $scope.searchCity = function(){
      if ( $("#autocomplete-city").val().length >= 3 ){
        $scope.founded_cities = []
        $.ajax({
          url: "http://www.jerevedunemaison.com/cities/autocompletion.json?term="+$("#autocomplete-city").val(),
          success: function (response) {
            for (item in response){
              $scope.founded_cities.push(response[item])
            }
          }
        });
      }
    }

    $scope.changeCityFilter = function(name){
      city_name = name.split(" (")[0]
      if ( filterManager.filterAlreadyExist("city_name") ){
        filterManager.addOrFilter("city_name", city_name)
      }else{
        filterManager.add("city_name", city_name, null, "houses");
      }
      $scope.founded_cities = []
    }

    $scope.config = {};

    $scope.oldValue = null;
  });
});
